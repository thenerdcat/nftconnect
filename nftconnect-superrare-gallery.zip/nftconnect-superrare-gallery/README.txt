=== Plugin Name ===
Contributors: Fernando Torres
Donate link: https://thenerdcat.com/
Tags: nft,superrare
Requires at least: 4.7
Tested up to: 5.7
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This tool will make sharing NFT’s from SuperRare easier to bloggers and news companies using WordPress, and at the same time will serve as a growth hacking tool for building backlinks for SuperRare.

== Description ==

This tool will make sharing NFT’s from SuperRare easier to bloggers and news companies using WordPress, and at the same time will serve as a growth hacking tool for building backlinks for SuperRare.

You can check more details at thenerdcat.com/nftconnect

== Frequently Asked Questions ==


== Screenshots ==



== Changelog ==

= 1.0 =

== A brief Markdown ==
