=== Plugin Name ===
NFTConnect

== Description ==

This tool will make sharing NFT’s from SuperRare easier to bloggers and news companies using WordPress, and at the same time will serve as a growth hacking tool for building backlinks for SuperRare.

== Installation ==

Download the files, install and activate the plugin in Wordpress

Check more information and a Live Demo at https://thenerdcat.com/nftconnect